package com4.garagerepar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GaragereparApplicationTests {

	@Test
	void contextLoads() {
	}

}
